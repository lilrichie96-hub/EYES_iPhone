# EYES for iPhone 2.6.6 · update package (not a complete site)

I didn't have the iPhone 2.6.3 site. It isn't in Drive, and I couldn't open the EYES_iPhone repo from here. So this package is the shared code plus merge steps, not a full site ZIP. **Merge it into the 2.6.3 site. Don't unzip it over the site.**

## 1. New files: add as-is
- `files/eyes-playtime.js`
- `files/eyes-playtime.css`

## 2. Shared files that changed
For each file below, compare the 2.6.3 copy with Android build 120's copy first:
- If they're identical, replace the 2.6.3 file with the one in `files/`.
- If 2.6.3 differs, it probably holds the 2.6.3 pointer and ability cleanup fixes. Keep the 2.6.3 file and apply the matching diff from `diffs/` instead, so those fixes survive.

The files:
- `ability-wheel.js`: the six-ability layout. The blanket "no satellite on iPhone" line is removed; each ability's `available()` decides instead.
- `ability-wheel.css`: label placement. The home rows also recede while the wheel is open.
- `launcher.js`: pose hooks (lean, hop, hide, pupil). Safe-area insets are now read on iPhone. The `blocked()` iPhone early return is removed. Adds `Haven.playtime()`.
- `eyes-play.js`: staring-contest personality.
- `eyes-social.js`: The Optic's Play row opens the new Play.

## 3. iPhone index.html (keep yours, add two lines)
- In `<head>`, after the last stylesheet: `<link rel="stylesheet" href="eyes-playtime.css" />`
- After `weather.js` (or after `ability-wheel.js` if weather.js isn't loaded), as the last script: `<script src="eyes-playtime.js"></script>`
- Version label: `EYES for iPhone 2.6.6`.

## 4. sw.js
- Set the cache name to `eyes-web-2.6.6`.
- Add `eyes-playtime.js` and `eyes-playtime.css` to the precache list.
- The old cache is dropped on activate as before. Saved data in localStorage and IndexedDB is not touched.

## What iPhone users get
- The satellite appears on iPhone for the first time. It holds Eye Contact and Play only, because Vision, Arcade, Pocket and Weather still report themselves unavailable there.
- The dock's Eye Contact shortcut stays as it is.

## Check on a real iPhone (WebKit wasn't available here)
- Tap the satellite, open each ability, and close it again, 5 times.
- Play each Play activity with real touch.
- Open Eye Contact from the dock.
- Lock the phone during Play.
