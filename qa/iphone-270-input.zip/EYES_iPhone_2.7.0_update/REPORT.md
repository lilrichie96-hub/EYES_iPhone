# EYES 4.7.0 (Android build 122) / iPhone 2.7.0 · Hangout 2.0: the Playdate update

- **Baseline:** `EYES_4.6.6_build121_SIGNED.apk`.
- **What changed:** only web assets, plus the manifest version.
  - The dex, `resources.arsc`, `res/` and the package id are unchanged, so it installs over 4.6.6 once Patch signs it.
- **Version:** manifest versionCode **122**, versionName **4.7.0**. The in-app label reads EYES 4.7.0.
- **APK:** `EYES_4.7.0_build122_UNSIGNED.apk`, SHA-256 `fc2dc0282dd05f7637ab5b4de39983f3f4f6cac191548b774975b9a0236274aa`.
  - It's unsigned: the old v1 signature was removed and there's no signing block.
  - Stored entries are 4-byte aligned.
  - A throwaway test signature verified (`jar verified`).
- **Files changed (4):**
  - `assets/eyes-hangout.js`
  - `assets/eyes-hangout.css`
  - `assets/eyes-contact.js` (3 lines)
  - `assets/index.html` (version label only)
- **iPhone:** delivered as an update package with patches. The 2.6.7 source couldn't be reached from this session (see Limitations).

## What it does now

### Within the first five seconds
- The arrival now lasts 3.4 s instead of 5.2 s. They notice each other and say hello in character.
- The first real activity is always a lively one: mischief, goofing, bubbles or tag. By design it starts 3.9–4.8 s in; across 300 random pairings it started by 5 s every time.
- The longest gap between activities is 1.4 s.
- Quiet company still happens. It's shorter now (12–55 s) and has small shared moments in it.

### New shared activities
Each one is a sequence of action and reaction, not a single animation.

**Tug of war**
- A strand of light grows out of both Eyes and meets in the middle.
- They crouch and grab. Shy Eyes hesitate first.
- Then they pull in waves: leaning back, stretched toward the strand, wobbling. The knot drifts toward whoever is winning.
- Outcomes:
  - Win by dragging: the loser tumbles forward.
  - Grip slip: the winner falls over backwards.
  - A mischievous Eye lets go as a joke: the other flies back.
  - Snap: both bounce back.
- Reactions depend on temperament:
  - Winners: cheer, smug tilt, or a shy little hop.
  - Losers: a quick "again!", a glare, a dramatic flop, or a shy hide.
- Recovery speed follows each Eye's temperament.
- An affectionate winner goes over and comforts a sulking loser.

**Tag**
- One Eye bumps the other and darts off.
- They shrink to about 74 % to have room to run.
- Each round is one of these:
  - Chase: ends in a catch, or a dodge with the chaser overshooting.
  - Feint: a lunge, a flinch, a smug pause.
  - Hide: the runner crouches at the edge while the other searches.
  - Surprise attack: the runner pounces out of hiding.
  - Collision in the middle: they bonk and get dizzy.
- At the end, the last one left "it" grumbles or bounces.
- Eyes never leave the screen; this was measured at four screen sizes.

**Bubble party**
- The Eyes conjure bubbles: each one puffs up before releasing one.
- Each Eye goes after its own planned bubbles. It crouches and then hops, and a thin flash from its eye pops the bubble.
- Owners can tap any bubble to pop it.
- Surprises:
  - Sparkle showers.
  - Three tiny fireflies.
  - A colourful burst: shy Eyes flinch, dramatic ones wobble, energetic ones cheer.
  - Three small extra bubbles.
  - A chain that pops the next two.
- If you pop a bubble an Eye was going for, it reacts: grumpy Eyes glare at you.

**Dance off**
- The Eyes take turns showing off with 9 moves. Four are new: twirl, sway, stomp, slide.
- An answer is never a copy of the move before it.
- The responder's attitude:
  - Eager.
  - Reluctant: looks at its owner first, then warms up.
  - Embarrassed: a tiny move, then it hides with a faint rosy glow.
  - Unimpressed: a slow blink, then one perfect move and a smug tilt.
- Dancing Eyes leave trails in complementary colours.
- The finale is a spin together with a coordinated slow blink, or a solo finish with the other one reacting.

**Curious discoveries**
- An object materialises between the Eyes.
- One Eye notices first. The other perks up, or a shy one startles.
- They creep closer and swap glances. The object twitches three times, faster each time, and they flinch.
- For the last 1.2 s it glows and trembles while they lean right in.
- Then one of these:
  - An egg hatches fireflies. The shell fades.
  - An orb starts bouncing around and bonks someone.
  - A tiny critter with legs scurries about, hides, then bolts off the edge.
  - A crystal bursts into confetti.
  - A magnet pulls both Eyes into an embarrassed squish, then lets go.
- Owners can tap the object. It shakes, and both Eyes react.

**Mischief**
- Tricks:
  - Sneak, poke, look away, fake whistle.
  - Duck and "boo".
  - Steal the other's glowing pebble.
  - Fake sleep, then pop awake when the other leans in to check.
  - A sideways bump.
- The other Eye responds by retaliating, investigating until the prankster cracks, getting annoyed, giggling, or sulking (and getting comforted).

**Company moments** (planned, so both screens show them)
- Nudges and leaning together.
- Coordinated slow blinks.
- Following each other's gaze to look at the same spot.
- Little pokes, fake naps, small startles.

**Kept exactly as they were:** catch (ball ownership and toss protocol), fireflies, goofing, farewells, sound, invitations.

### Owner participation
- Three understated pill buttons sit under the Meeting Space: **Play**, **Tease**, **Surprise**.
  - On screens under 340 px wide they show icons only.
  - In landscape they sit tighter.
- When one is pressed, that owner's Eye glances down at its person first. The other phone sees the same glance, plus a short line such as "Moss wants them to play."
  - **Play** chooses a shared activity from both temperaments and what they did lately.
  - **Tease** starts mischief. A very sweet Eye may decline and give a gentle nudge instead.
  - **Surprise** brings in a discovery.
- Cooldowns:
  - 9 s per owner.
  - 7 s between any two used nudges from either owner.
  - None during the arrival.
- Direct touch:
  - During tug, hold anywhere to cheer.
  - During tag and dance, tap to encourage your Eye.
  - Pop bubbles; poke the object.
  - Tap an Eye to tease it, as before.
- Cheering shows as small rising sparks on both phones.
  - In tug of war it can change who wins: in testing, B's cheering flipped the result to B on both screens.
  - In dance, a cheered-on Eye adds an extra flourish.
- Nobody has to touch anything. Hangout keeps going on its own.

### Personality
Every new trait comes from the same five dials already exchanged when two Eyes meet: competitive, mischievous, affectionate, attention span, recovery and initiative. Nothing new is stored or sent about an Eye.

What the planner chooses over 30 activities, by pairing:
- **Two energetic Eyes:** tag 13 %, catch 12 %, goofing 12 %, company 13 %.
- **Two sleepy Eyes:** company 25 %, bubbles 16 %, fireflies 15 %. Tag rarely happens.
- **A shy Eye with a dramatic one:** dances where the shy one is embarrassed in 56 % of cases.

## Sync and networking
- **Planner v3 is still a pure function.** Both phones compute the same activities from the shared seed, the dials, and the list of owner nudges.
  - A nudge is data: who, a number, when, which. The planner alone decides whether it's used, so two simultaneous presses resolve the same way on both phones.
- **New messages go only between two v3 phones:**
  - `cue`: the nudge, resent until confirmed, carrying a short history.
  - `cueok`: the confirmation.
  - `push`: cumulative cheering, at most 1 every 2 s.
  - `pop`: popped bubbles, batched at most every 1.2 s.
  - `obj`: object touches.
  - `res`: the tug outcome, sent twice by the inviter's phone.
  - `hi` and `back` can also carry the nudge history, which repairs a lost nudge.
- **Budget:** owner-input messages have their own budget of 70 per rolling hour and pause while the relay is cooling down.
- **Never sent between phones:** animation, positions or raw touches.
- **Backend:** no changes, no new Firebase paths.
- **Older phones:** with a 4.5–4.6.6 or 2.5–2.6.x phone, both run the exact v2 Hangout. The nudges stay hidden and nothing new is sent.
- **Unchanged:** reconnection, away, goodbye and the silence timeouts.

## Performance and battery
- The frame rate is 60 fps only while an activity is moving; otherwise 30.
- New: when nothing at all is moving in a quiet moment, the Meeting Space drops to about 20 fps.
- Battery saver, ≤ 15 % battery and Gentle motion keep their existing limits. Motion Off still says Hangout needs motion.
- Effects are capped:
  - Sparks ≤ 220, fireflies ≤ 28, confetti ≤ 120, cheering sparks ≤ 90, extra bubbles ≤ 18.
  - Every toy is cleared when an activity ends and on teardown.
- In a simulated 45-minute session with owners joining in, peak counts were small (sparks 49, confetti 46), and heap went from 7.2 to 9.4 MB.

## Verification

### Automated (Node and headless Chromium)
Two phones were run as **two independent sessions**: one in Android mode, one in iPhone mode (`EYES_WEB`, iPhone UA, touch). Each had its own seeded Eye and friendship, joined by a test relay that can add latency, loss, duplicates and reordering.

**Planner (Node):**
- v1 and v2 schedules are **identical to 4.6.6's**: 600 schedules × 60 activities compared.
- v3 gives the same result whatever order nudges arrive in, including duplicates (300 sessions).
- Used nudges respect the 7 s gap.
- No activity ever repeats back to back.

**Every activity on two phones:** mischief, tug, tag, bubbles, dance, discover, company, catch, fireflies, goof. The same activity was showing on both screens throughout, with zero JS errors on either phone.

**Nudges:**
- Surprise from A, Tease from B, Play from A: the same activity ran on both phones.
- Simultaneous presses: identical verdicts on both phones (A's used, B's declined) and identical plans.

**Network faults:**
- 35 % loss, 30 % duplicates, 40 % reordering: plans stayed identical.
- All nudge messages blocked: plans differed until the next keepalive carried the history, then were identical again.
- Total loss: both phones ended the Hangout at the silence limit.

**Cheering and shared objects:**
- Tug of war with cheering: the same result on both phones.
- A bubble popped on A popped on B.

**4.6.6 compatibility** (an unmodified 4.6.6 phone served side by side, 4 rounds, each side inviting):
- Live on v2, plans identical.
- No new messages sent, controls hidden.
- No errors on the old phone.

**Lifecycle:**
- Leaving and reopening 5 times, alternating who leaves.
- Closing with × mid-tug.
- Backgrounding either phone and coming back; going past the hidden limit.
- Afterwards there were no leftover canvases, cards or sessions.

**Screen sizes:**
- Tested at 320×568, 673×841 (foldable-like), 844×390 and 915×412 (landscape), during tag, tug, dance and discover.
- 640 position samples per size: **0 off-screen**.

**After Hangout:**
- The satellite reopens with the same items as 4.6.6 in this environment.
- Play opens, runs catch and closes.
- Arcade opens and backs out to idle.

**Build:**
- All scripts pass `node --check`.
- The zip tests clean and alignment is OK.
- Only the 5 intended entries differ from 4.6.6.
- A smoke test re-ran on the assets extracted from the final APK.

### Not verified here (needs devices)
- **WebKit / real iPhone Safari and the Home Screen app.** WebKit isn't installed in this environment, so all iPhone checks ran in Chromium with iPhone emulation.
- **Physical Android, including Android 17:**
  - Touch feel, haptics and frame pacing of the new activities.
  - Real Back and Home gestures.
  - Installing over 4.6.6 after Patch signs it.
- **Real foldables and rotation mid-activity.**
- **The real relay's latency.** The test relay used 0.25–0.6 s; Hangout is designed for about 1 s.
- **Vision on the satellite.** It doesn't appear in headless Chromium (no camera), for 4.6.6 as well as 4.7.0.
- **Whether it's actually funny.** Do people laugh? That's Richie's call.

## Remaining limitations
- **iPhone 2.6.7 source unavailable.** Attaching `lilrichie96-hub/EYES_iPhone` was refused from this session.
  - The iPhone package is the three shared files plus unified diffs against 4.6.6, applied with `git apply --3way`.
  - Patch should merge them into 2.6.7 and bump its label to 2.7.0.
- **The tug result depends on one message.** If both copies of the `res` message are lost, or arrive more than about 1 s after the reveal, the receiving phone falls back to the plan's own winner. The two screens could then disagree about that one tug. Nothing else is affected.
- **Brief timing jumps.** A nudge that arrives very late can make the other phone's current activity jump to catch up. This only happens under heavy delay.
- **Small differences in two places.** Each phone draws its bounces locally, so the bouncing orb and the critter's dash can look slightly different on the two screens. What appears and how it ends are the same on both.
- **No Gradle/Java project.** As before, the source ZIP is the APK tree plus build tooling, tests and patches.
