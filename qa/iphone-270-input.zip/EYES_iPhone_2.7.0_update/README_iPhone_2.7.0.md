# EYES iPhone 2.7.0 · Hangout 2.0 (the Playdate update)

This update pairs with Android 4.7.0 (build 122). **Both platforms run the same Hangout code.** Nothing here is a simplified or iPhone-only version.

## Read this first: what this package is based on

The iPhone 2.6.7 source (repo `lilrichie96-hub/EYES_iPhone`) couldn't be opened from this session, so these files weren't built on top of 2.6.7. They are the Android 4.6.6 (build 121) shared web files with the 4.7 changes added.

Only three shared files changed, and none of them are iPhone-specific:

| File | Change |
|---|---|
| `eyes-hangout.js` | Hangout 2.0: planner v3, all new activities, the owners' nudges, the new sync messages |
| `eyes-hangout.css` | The Play / Tease / Surprise controls (appended at the end) |
| `eyes-contact.js` | One small hook: a quiet Hangout moment may draw at about 20 fps (3 lines inside `frame()`) |

No new files were added and no `<script>` tags changed. Firebase, rules and the backend are untouched.

## How to apply (for Patch)

1. **If 2.6.7's copies of these three files match Android 4.6.6's copies** (the usual case, since they're shared), replace them with the copies in `files/`.
2. **If 2.6.7 changed any of them**, apply the matching unified diff from `patches/` instead:
   `git apply --3way patches/eyes-hangout.js.patch` (and so on for the other two).
   The diffs are against Android 4.6.6, so `--3way` lets git merge them around 2.6.7's own edits.
   - The `eyes-contact.js` change is three lines in `frame()`, so it should merge cleanly.
   - The `eyes-hangout.css` change is appended at the end, so it should also merge cleanly.
3. Bump the iPhone version label to **2.7.0** wherever 2.6.7 shows it (on Android it's `<p class="version">` in `index.html`).
4. Keep any 2.6.x iPhone fixes outside these files, such as pointer cleanup and Home Screen cleanup. Hangout 2.0 doesn't touch them.

## Compatibility

- An iPhone on 2.7 and an Android on 4.7 get the full Playdate.
- Either one paired with an older phone (Android 4.5–4.6.6, iPhone 2.5–2.6.x) automatically gets the old Hangout, activity for activity. The nudges don't show, and no new messages are sent to the older phone. This was tested against an unmodified 4.6.6 in both directions.

## What to check on a real iPhone

These checks have only been done in Chromium with iPhone emulation. WebKit wasn't available here.

- Safari and the Home Screen app: tap on bubbles, hold to cheer during tug of war, and use the three nudges.
- Sound only starts after a tap, which is normal for iOS.
- Rotate during tag and dance.
- Send the app to the background mid-activity and come back.
